// Background service script
