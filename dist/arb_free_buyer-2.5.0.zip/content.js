(() => {
  const api = typeof browser !== "undefined" ? browser : chrome;
  let timer = null;
  let scanTimer = null;
  let running = false;
  let isPurchased = false;
  let settings = {
    mode: "range",
    min: 100,
    max: 50000,
    fixed: 100,
    latency: 500,
    tab: "OTP-UPI",
    autoRefresh: true,
    autoBuy: true
  };

  // If already loaded in this page context, clean up previous instance
  if (window.__arbBuyerInstance) {
    try {
      window.__arbBuyerInstance.stop();
    } catch(e) {}
  }

  // Ensure any lingering debug box from previous versions is completely removed
  function removeOldDebug() {
    try {
      const box = document.getElementById("__otp_monitor_debug");
      if (box) box.remove();
    } catch(e) {}
  }
  removeOldDebug();
  try {
    const style = document.createElement("style");
    style.id = "__arb_cleaner";
    style.textContent = "#__otp_monitor_debug { display: none !important; opacity: 0 !important; pointer-events: none !important; }";
    (document.head || document.documentElement).appendChild(style);
  } catch(e) {}

  function log(...args) {
    console.log("[ARB Free Buyer]", ...args);
  }

  function findTargetTab(targetName = "OTP-UPI") {
    const norm = (targetName || "OTP-UPI").trim().toUpperCase();
    const tabs = [...document.querySelectorAll('[role="tab"], .van-tab')];
    return tabs.find(tab => {
      const titleEl = tab.querySelector(".tab-title, .van-tab__text");
      const text = (titleEl ? titleEl.textContent : tab.textContent || "").trim().toUpperCase();
      if (norm === "UPI") {
        // Match pure UPI and exclude OTP-UPI
        return (text.startsWith("UPI") || /\\bUPI\\b/.test(text)) && !text.includes("OTP");
      }
      return text.startsWith(norm) || text.includes(norm);
    });
  }

  function isTargetTabActive(targetName = "OTP-UPI") {
    const tab = findTargetTab(targetName);
    if (!tab) return false;
    return tab.getAttribute("aria-selected") === "true" ||
           tab.classList.contains("van-tab--active");
  }

  function realClick(el) {
    if (!el) return false;

    try { el.scrollIntoView({block: "nearest", inline: "nearest"}); } catch(e) {}
    try { el.focus(); } catch(e) {}
    try { el.click(); } catch(e) {}

    const opts = {bubbles: true, cancelable: true, view: window, buttons: 1, button: 0};
    for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
      try {
        el.dispatchEvent(new MouseEvent(type, opts));
      } catch(e) {}
    }

    return true;
  }

  // Switch to target tab ONLY if not already active (never repeatedly during refresh loop!)
  function ensureTargetTab() {
    const targetName = settings.tab || "OTP-UPI";
    if (isTargetTabActive(targetName)) {
      return false; // Already active, do not click to prevent resetting to range page
    }
    const tab = findTargetTab(targetName);
    if (!tab) {
      log(`Target tab "${targetName}" not found`);
      return false;
    }
    log(`Switching to target tab "${targetName}"`);
    realClick(tab);
    setTimeout(() => {
      const current = findTargetTab(targetName);
      if (current && current.getAttribute("aria-selected") !== "true") {
        const child = current.querySelector(".tab-title, .van-tab__text, .van-tab__text-ellipsis");
        if (child) realClick(child);
      }
    }, 60);
    return true;
  }

  // Locate the filter / switch icon (smartChange.svg next to Tips banner)
  function findFilterButton() {
    return document.querySelector(".switch-btn") ||
           document.querySelector(".x-buyList-switchbar img") ||
           document.querySelector('img[src*="smartChange"]') ||
           document.querySelector(".x-buyList-switchbar .switch-btn") ||
           null;
  }

  // Single click on the filter toggle button (avoids double-firing)
  function clickFilterButton() {
    const filterBtn = findFilterButton();
    if (!filterBtn) {
      log("Filter button (switch-btn) not found");
      return false;
    }
    filterBtn.click();
    return true;
  }

  // Verify if individual orders list is active (NOT the range page)
  function isIndividualMode() {
    return Boolean(
      document.querySelector(".x-buyList-filter") ||
      document.querySelector(".item[platformorder]") ||
      document.querySelector("[platformorder]")
    );
  }

  // Dynamic order book detector: works across any domain and route without relying on URLs
  function isOrderBookPage() {
    // If "Select Method Payment" or other payment/order screen is visible
    const titleEl = document.querySelector(".van-nav-bar__title, .navbar .title, .van-nav-bar");
    const titleText = (titleEl ? titleEl.textContent : "").trim().toLowerCase();
    if (titleText.includes("select method") || titleText.includes("payment")) {
      return false;
    }

    // Must have the order book elements (tabs or buy list container)
    return Boolean(
      document.querySelector(".x-buyList") ||
      document.querySelector(".x-buyList-list") ||
      document.querySelector(".switch-btn") ||
      document.querySelector(".x-buyList-switchbar") ||
      document.querySelector('[role="tab"], .van-tab')
    );
  }

  // Checks if orders (either range or individual) have loaded in the DOM
  function areOrdersLoaded() {
    const items = document.querySelectorAll(".item");
    if (items.length === 0) return false;
    const hasLoading = Boolean(
      document.querySelector(".van-loading") ||
      document.querySelector(".van-toast--loading") ||
      document.querySelector('[class*="loadingLottie"]')
    );
    return !hasLoading;
  }

  // Checks if individual orders (with platformorder) are loaded
  function areIndividualOrdersLoaded() {
    return isIndividualMode() && document.querySelectorAll(".item[platformorder]").length > 0;
  }

  // Waits until orders are loaded in DOM before applying filter
  function waitForOrdersLoaded(timeout = 4000) {
    return new Promise(resolve => {
      if (areOrdersLoaded()) return resolve(true);
      const start = Date.now();
      const intv = setInterval(() => {
        if (!running || isPurchased) {
          clearInterval(intv);
          return resolve(false);
        }
        if (areOrdersLoaded()) {
          clearInterval(intv);
          return resolve(true);
        }
        if (Date.now() - start >= timeout) {
          clearInterval(intv);
          resolve(areOrdersLoaded());
        }
      }, 50);
    });
  }

  // Waits until individual order items are loaded in DOM
  function waitForIndividualOrdersLoaded(timeout = 3000) {
    return new Promise(resolve => {
      if (areIndividualOrdersLoaded()) return resolve(true);
      const start = Date.now();
      const intv = setInterval(() => {
        if (!running || isPurchased) {
          clearInterval(intv);
          return resolve(false);
        }
        if (areIndividualOrdersLoaded()) {
          clearInterval(intv);
          return resolve(true);
        }
        if (Date.now() - start >= timeout) {
          clearInterval(intv);
          resolve(areIndividualOrdersLoaded());
        }
      }, 50);
    });
  }

  let isRefreshing = false;

  // Refresh orders by clicking the filter icon - only when order is loaded!
  async function refreshOrders() {
    if (!running || isPurchased || isRefreshing) return;
    if (!isOrderBookPage()) return;

    // Apply filter only when the order is loaded
    if (!areOrdersLoaded()) return;

    isRefreshing = true;
    clickFilterButton();

    // Wait until new orders are loaded after clicking filter
    await waitForOrdersLoaded(2000);
    isRefreshing = false;

    if (running && !isPurchased) {
      scanOrders();
    }
  }

  function findBuyButton(card) {
    if (!card) return null;
    const buttons = [...card.querySelectorAll("button, .btn, .x-btn, .van-button")];
    const buyBtn = buttons.find(b => /buy/i.test(b.textContent || ""));
    if (buyBtn) return buyBtn;
    return card.querySelector(".van-button--primary, .x-btn, .btn") || card.querySelector("button") || null;
  }

  function clickBuyButton(card, amount) {
    const btn = findBuyButton(card);
    if (!btn) return false;

    const disabled = btn.disabled ||
                     btn.classList.contains("van-button--disabled") ||
                     btn.classList.contains("van-button--loading") ||
                     btn.getAttribute("aria-disabled") === "true";
    if (disabled) return false;

    // Prevent double-clicking the exact same DOM element in rapid succession (< 500ms)
    const now = Date.now();
    if (btn._lastClickTime && (now - btn._lastClickTime < 500)) {
      return false;
    }
    btn._lastClickTime = now;

    const po = card.getAttribute("platformorder") || "";
    log(`AUTO-BUY: Clicked Buy for ₹${amount || "?"} order=${po}`);

    realClick(btn);

    const child = btn.querySelector(".van-button__text, .van-button__content");
    if (child) {
      realClick(child);
    }
    return true;
  }

  // Only return individual order cards (strictly ignores range cards)
  function getOrderCards() {
    if (!isIndividualMode()) return [];

    const items = [...document.querySelectorAll(".item[platformorder], [platformorder]")];
    const seenCards = new Set();
    const result = [];
    for (const el of items) {
      const card = el.closest("[platformorder]") || el;
      if (!seenCards.has(card)) {
        seenCards.add(card);
        if (findBuyButton(card)) {
          result.push(card);
        }
      }
    }
    return result;
  }

  function parseAmount(card) {
    if (!card) return NaN;

    // Direct attribute on individual order item
    const maxAttr = card.getAttribute("maximumamount");
    if (maxAttr && !isNaN(Number(maxAttr))) {
      return Number(maxAttr);
    }

    const amountNode = card.querySelector(".amount, [class*='amount'], [class*='price']");
    if (amountNode) {
      const text = amountNode.textContent || "";
      const m = text.replace(/,/g, "").match(/([0-9]+(?:\\.[0-9]+)?)/);
      if (m) return Number(m[1]);
    }

    // Ignore range text (e.g., "100 - 200") unless explicitly an individual order
    const text = card.textContent || "";
    if (/\\d+\\s*-\\s*\\d+/.test(text) && !card.getAttribute("platformorder")) {
      return NaN;
    }

    const m = text.replace(/,/g, "").match(/₹\\s*([0-9]+(?:\\.[0-9]+)?)/);
    if (m) return Number(m[1]);

    return NaN;
  }

  function matches(amount) {
    if (!Number.isFinite(amount)) return false;
    if (settings.mode === "fixed") return amount === Number(settings.fixed);
    return amount >= Number(settings.min) && amount <= Number(settings.max);
  }

  // Scan only individual orders - zero operations on the range page
  function scanOrders() {
    if (!running || isPurchased) return;
    if (!isOrderBookPage()) return;

    // Do nothing on range page
    if (!isIndividualMode()) return;

    const cards = getOrderCards();
    if (cards.length === 0) return; // Only process when orders are loaded
    let matchesFound = 0;

    for (const card of cards) {
      const amount = parseAmount(card);
      if (!matches(amount)) continue;

      matchesFound++;

      if (settings.autoBuy) {
        const clicked = clickBuyButton(card, amount);
        if (clicked) {
          isPurchased = true;
          const po = card.getAttribute("platformorder") || "";
          log(`Order ₹${amount} (${po}) purchased! Turning off buying process.`);
          stop();
          try {
            api.runtime.sendMessage({
              type: "ORDER_PURCHASED",
              amount,
              order: po
            });
          } catch (e) {}
          return; // Stop scanning and terminate buying permanently
        }
      }
    }

    if (matchesFound > 0) {
      log(`Scanned ${cards.length} individual orders; ${matchesFound} matching`);
    }
  }

  let observer = null;

  function stop() {
    running = false;
    if (timer) clearInterval(timer);
    if (scanTimer) clearInterval(scanTimer);
    timer = scanTimer = null;
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    log("Stopped");
  }

  function start(s) {
    stop();
    isPurchased = false;
    removeOldDebug();
    settings = Object.assign(settings, s || {});
    const parsedLatency = Number(settings.latency);
    settings.latency = isNaN(parsedLatency) ? 500 : Math.max(0, parsedLatency);
    settings.fixed = isNaN(Number(settings.fixed)) ? 0 : Math.max(0, Number(settings.fixed));
    let minVal = isNaN(Number(settings.min)) ? 0 : Math.max(0, Number(settings.min));
    let maxVal = isNaN(Number(settings.max)) ? minVal + 1 : Math.max(0, Number(settings.max));
    if (minVal >= maxVal) {
      if (minVal > maxVal) {
        [minVal, maxVal] = [maxVal, minVal];
      } else {
        maxVal = minVal + 1;
      }
    }
    settings.min = minVal;
    settings.max = maxVal;
    settings.tab = settings.tab || "OTP-UPI";
    settings.autoBuy = settings.autoBuy !== false;

    running = true;
    log(`Started; tab=${settings.tab}; latency=${settings.latency}ms; autoBuy=${settings.autoBuy}`);

    // Watch DOM for when order is bought or screen switches away from buy list
    if (observer) observer.disconnect();
    observer = new MutationObserver(() => {
      if (running && !isOrderBookPage()) {
        log("Screen changed away from order book (e.g. payment screen reached). Turning off buying process.");
        stop();
        try {
          api.runtime.sendMessage({ type: "ORDER_PURCHASED" });
        } catch (e) {}
      }
    });
    observer.observe(document.body || document.documentElement, {
      childList: true,
      subtree: true
    });

    // If needed, switch tab ONCE at start (never continuously in refresh loop!)
    const switchedTab = ensureTargetTab();

    // Apply select filter only when the order is loaded
    (async () => {
      if (switchedTab) {
        await new Promise(r => setTimeout(r, 200));
      }
      // Wait until orders are loaded in DOM before applying filter
      await waitForOrdersLoaded();
      if (!running || isPurchased) return;

      if (!isIndividualMode()) {
        log("Order loaded; applying filter to switch to individual orders");
        clickFilterButton();
        await waitForIndividualOrdersLoaded();
      }

      if (running && !isPurchased) {
        scanOrders();
      }
    })();

    // Auto-refresh: clicks filter icon repeatedly to refresh individual orders (never clicks OTP-UPI tab)
    if (settings.autoRefresh) {
      const refreshInterval = Math.max(200, settings.latency);
      timer = setInterval(() => {
        if (!running) return;
        refreshOrders();

        setTimeout(() => {
          if (running) scanOrders();
        }, 150);
      }, refreshInterval);
    }

    // High frequency order scanner to instantly catch orders when DOM updates
    scanTimer = setInterval(() => {
      if (running) scanOrders();
    }, 80);
  }

  window.__arbBuyerInstance = {
    stop,
    start,
    getStatus: () => ({ running, tab: settings.tab || "OTP-UPI" })
  };

  if (window.__arbBuyerMessageListener) {
    try {
      api.runtime.onMessage.removeListener(window.__arbBuyerMessageListener);
    } catch (e) {}
  }

  const messageHandler = (msg, sender, sendResponse) => {
    if (!msg) return;
    if (msg.type === "START") {
      start(msg);
      if (sendResponse) sendResponse({ ok: true });
      return Promise.resolve({ ok: true });
    } else if (msg.type === "STOP") {
      stop();
      if (sendResponse) sendResponse({ ok: true });
      return Promise.resolve({ ok: true });
    } else if (msg.type === "CLICK_TAB") {
      ensureTargetTab();
      if (sendResponse) sendResponse({ ok: true });
      return Promise.resolve({ ok: true });
    } else if (msg.type === "GET_STATUS") {
      const res = {
        running,
        tab: settings.tab || "OTP-UPI"
      };
      if (sendResponse) sendResponse(res);
      return Promise.resolve(res);
    }
  };

  function checkNavigation() {
    if (running && !isOrderBookPage()) {
      log("Screen changed away from order book; turning off buying process");
      stop();
      try {
        api.runtime.sendMessage({ type: "ORDER_PURCHASED" });
      } catch (e) {}
    }
  }

  window.addEventListener("hashchange", checkNavigation);
  window.addEventListener("popstate", checkNavigation);

  window.__arbBuyerMessageListener = messageHandler;
  api.runtime.onMessage.addListener(messageHandler);
})();
